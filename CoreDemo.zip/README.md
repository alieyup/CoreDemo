Murat YÜCEDAĞ anlatımı ile  Asp.Net Core 5.0 Proje Kampı Eğitimi Tamamlama ve Uygulama Projesi

https://www.youtube.com/playlist?list=PLKnjBHu2xXNNkinaVhPqPZG0ubaLN63ci
