﻿namespace CoreDemo.Models
{
	public class UserComment
	{
		public int ID { get; set; }
		public string UserName { get; set; }
	}
}
